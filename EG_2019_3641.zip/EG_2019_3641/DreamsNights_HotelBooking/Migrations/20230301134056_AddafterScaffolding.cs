﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DreamsNights_HotelBooking.Migrations
{
    public partial class AddafterScaffolding : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
